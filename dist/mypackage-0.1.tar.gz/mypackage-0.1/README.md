#mypackage
This library contains an example of a python packages

##building this python locally
`python setup.py sdist`

##installing this package from github
`pip install git+https://github.com/nelebogo/example-python-package.git`

##updating this package from github
`pip install --upgrade git+https://github.com/nelebogo/example-python-package.git`
